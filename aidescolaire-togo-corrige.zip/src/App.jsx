import React from 'react'

function App() {
  return (
    <h1>Bienvenue sur AideScolaire Togo !</h1>
  )
}

export default App
